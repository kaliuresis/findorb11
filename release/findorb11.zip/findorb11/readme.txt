Usage: findorb11.exe [SEED] [OPTION]
Searches for locations where a great chest will spawn orb_11 in Noita. Search takes place in a spiral around the specified starting position.

Options:
    seed            = [integer] - world seed, defaults to 0
    ng, NG, newgame = [integer] - newgame number, equivalent to adding this number to the world seed, defaults to 0
    x, X            = [double]  - starting x position, defaults to 0.0
    y, Y            = [double]  - starting y position, defaults to 0.0
